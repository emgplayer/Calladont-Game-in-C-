#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct graph{
    char **words;
    int **mat;
    int n;
}Graph;

int kaladont_next(char* word1, char* word2)
{
    int len = strlen(word1);

    return (word1[len - 2] == word2[0] &&
            word1[len - 1] == word2[1]);
}

void create_empty(Graph *g)
{
    for(int i = 0; i < g->n; i++)
        for(int j = 0; j < g->n; j++)
            g->mat[i][j] = 0;
}

void free_graph(Graph *g)
{
    for(int i = 0; i < g->n; i++)
    {
        free(g->words[i]);
        free(g->mat[i]);
    }
    free(g->words);
    free(g->mat);
    free(g);
}

void print_graph(Graph *g)
{
    for(int i = 0; i < g->n; i++)
    {
        for(int j = 0; j < g->n; j++)
        {
            printf("%d", g->mat[i][j]);
        }
        printf("\n");
    }
}

void add_graph(Graph **g, char *word)
{
    Graph *curr = *g;

    int old_n = curr->n;
    curr->n++;

    curr->mat = realloc(curr->mat, curr->n * sizeof(int*));
    for(int i = 0; i < curr->n; i++)
        curr->mat[i] = realloc(curr->mat[i], curr->n * sizeof(int));

    curr->words = realloc(curr->words, curr->n * sizeof(char*));

    curr->words[curr->n - 1] = malloc(strlen(word) + 1);
    strcpy(curr->words[curr->n - 1], word);

    for(int i = 0; i < curr->n; i++)
    {
        curr->mat[i][curr->n - 1] = 0;
        curr->mat[curr->n - 1][i] = 0;
    }
}

void delete_vertex(Graph *g, char *word)
{
    int idx = -1;

    for(int i = 0; i < g->n; i++)
    {
        if(strcmp(g->words[i], word) == 0)
        {
            idx = i;
            break;
        }
    }

    if(idx == -1)
        return;

     free(g->words[idx]);

    for(int i = idx; i < g->n - 1; i++)
    {
        g->words[i] = g->words[i + 1];
    }

     for(int i = idx; i < g->n - 1; i++)
    {
        for(int j = 0; j < g->n; j++)
        {
            g->mat[i][j] = g->mat[i + 1][j];
        }
    }

    for(int i = 0; i < g->n - 1; i++)
    {
        for(int j = idx; j < g->n - 1; j++)
        {
            g->mat[i][j] = g->mat[i][j + 1];
        }
    }

    g->n--;

    g->words = realloc(g->words, g->n * sizeof(char*));

    for(int i = 0; i < g->n; i++)
    {
        g->mat[i] = realloc(g->mat[i], g->n * sizeof(int));
    }
}

void delete_edge(Graph **g, char *word1, char *word2)
{
    int n;
    int m;
    Graph *curr = *g;

    for(int i = 0; i < curr->n; i++)
    {
        if((strcmp(curr->words[i], word1) == 0))
            n = i;
        if((strcmp(curr->words[i], word2) == 0))
            m = i;
    }

    curr->mat[n][m] = 0;
}

void add_edge(Graph **g, char *word1, char * word2)
{
    int n;
    int m;
    Graph *curr = *g;

    for(int i = 0; i < curr->n; i++)
    {
        if((strcmp(curr->words[i], word1) == 0))
            n = i;
        if((strcmp(curr->words[i], word2) == 0))
            m = i;
    }

    curr->mat[n][m] = 1;
}

void read_from_file(char *filename, Graph *g)
{
    FILE *f = fopen(filename, "r");

    fscanf(f, "%d", &g->n);

    if(f == NULL)
    {
        printf("Greska pri otvaranju fajla");
        return;
    }

    g->words = malloc(g->n * sizeof(char *));

    char buffer[100];

    for(int i = 0; i < g->n; i++)
    {
        fscanf(f, "%s", buffer);

        g->words[i] = malloc(strlen(buffer) + 1);

        strcpy(g->words[i], buffer);
    }

    g->mat = malloc(g->n * sizeof(int*));
    for(int i = 0; i < g->n; i++)
    {
        g->mat[i] = calloc(g->n, sizeof(int));
    }

    for(int i = 0; i < g->n; i++)
    {
        for(int j = 0; j < g->n; j++)
        {
            if(i != j && kaladont_next(g->words[i], g->words[j]))
            {
                g->mat[i][j] = 1;
            }
        }
    }

    fclose(f);
}

typedef struct{
    int *data;
    int top;
}Stack;

void push(Stack *s, int n)
{
    s->data[++(s->top)] = n;
}

int pop(Stack *s)
{
    return s->data[(s->top)--];
}

int empty(Stack *s)
{
    return s->top == -1;
}

void DFS(Graph *g, int start)
{
    int *visited = malloc(g->n * sizeof(int));
    for(int i = 0; i < g->n; i++)
        visited[i] = 0;

    Stack s;
    s.data = malloc(g->n * sizeof(int));
    s.top = -1;

    push(&s, start);

    while(!empty(&s))
    {
        int v = pop(&s);

        if(visited[v])
            continue;

        visited[v] = 1;

        printf("%s\n", g->words[v]);

        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[v][i] == 1 && !visited[i])
                push(&s, i);
        }
    }
}

int korisnost(Graph *g, int start)
{
    int *visited = calloc(g->n, sizeof(int));
    Stack s;
    s.data = malloc(g->n * sizeof(int));
    s.top = -1;

    push(&s, start);

    int count = 0;

    while(!empty(&s))
    {
        int v = pop(&s);

        if(visited[v]) continue;

        visited[v] = 1;
        count++;

        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[v][i] && !visited[i])
                push(&s, i);
        }
    }

    free(visited);
    free(s.data);

    return count - 1;
}

int efikasnost(Graph *g, int start)
{
    int *dist = malloc(g->n * sizeof(int));
    int *visited = calloc(g->n, sizeof(int));

    for(int i = 0; i < g->n; i++)
        dist[i] = -1;

    int queue[1000];
    int front = 0, rear = 0;

    queue[rear++] = start;
    visited[start] = 1;
    dist[start] = 0;

    while(front < rear)
    {
        int v = queue[front++];

        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[v][i] && !visited[i])
            {
                visited[i] = 1;
                dist[i] = dist[v] + 1;
                queue[rear++] = i;
            }
        }
    }

    int max = 0;
    for(int i = 0; i < g->n; i++)
        if(dist[i] > max)
            max = dist[i];

    free(dist);
    free(visited);

    return max;
}

int opasnost(Graph *g, int start)
{
    int *dist = malloc(g->n * sizeof(int));
    int *visited = calloc(g->n, sizeof(int));

    for(int i = 0; i < g->n; i++)
        dist[i] = -1;

    int queue[1000];
    int front = 0, rear = 0;

    queue[rear++] = start;
    visited[start] = 1;
    dist[start] = 0;

    while(front < rear)
    {
        int v = queue[front++];

        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[v][i] && !visited[i])
            {
                visited[i] = 1;
                dist[i] = dist[v] + 1;
                queue[rear++] = i;
            }
        }
    }

    int min = 1e9;

    int hasOut = 0;
    for(int i = 0; i < g->n; i++)
        if(g->mat[start][i])
            hasOut = 1;

    if(!hasOut)
        return 1;

    for(int i = 0; i < g->n; i++)
    {
        int out = 0;
        for(int j = 0; j < g->n; j++)
            if(g->mat[i][j]) out++;

        if(out == 0 && dist[i] != -1)
            if(dist[i] < min)
                min = dist[i] + 1;
    }

    free(dist);
    free(visited);

    if(min == 1e9)
        return 1;

    return min;
}

void menu(Graph *g)
{
    int choice;

    while(1)
    {
        printf("\n1. Korisnost\n");
        printf("2. Efikasnost\n");
        printf("3. Opasnost\n");
        printf("4. DFS prikaz\n");
        printf("0. Izlaz\n");

        scanf("%d", &choice);

        if(choice == 0) break;

        int idx;
        printf("Unesi indeks reci: ");
        scanf("%d", &idx);

        if(choice == 1)
            printf("Korisnost: %d\n", korisnost(g, idx));

        else if(choice == 2)
            printf("Efikasnost: %d\n", efikasnost(g, idx));

        else if(choice == 3)
            printf("Opasnost: %d\n", opasnost(g, idx));

        else if(choice == 4)
            DFS(g, idx);
    }
}

int random_word(Graph *g)
{
    return rand() % g->n;
}

int exists(Graph *g, char *word)
{
    for(int i = 0; i < g->n; i++)
    {
        if((strcmp(g->words[i], word)) == 0)
            return i;
    }
    return -1;
}

void play_game(Graph *g)
{
    int *used = calloc(g->n, sizeof(int));

    int current = rand() % g->n;
    used[current] = 1;

    printf("\nPOCETNA REC: %s\n", g->words[current]);

    while(1)
    {

        char input[100];

        printf("\nIGRAC -> Unesi sledecu rec: ");
        scanf("%s", input);

        int next = exists(g, input);

        if(next == -1)
        {
            printf("Rec ne postoji. KRAJ IGRE.\n");
            break;
        }

        if(used[next])
        {
            printf("Rec je vec koriscena. KRAJ IGRE.\n");
            break;
        }

        if(!g->mat[current][next])
        {
            printf("Nevalidan potez. KRAJ IGRE.\n");
            break;
        }

        used[next] = 1;
        current = next;

        printf("OK -> %s\n", g->words[current]);

        int hasMove = 0;
        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[current][i] && !used[i])
            {
                hasMove = 1;
                break;
            }
        }

        if(!hasMove)
        {
            printf("Nema poteza. TI POBEDUJES!\n");
            break;
        }

        printf("\nRACUNAR IGRA...\n");

        int options[1000];
        int count = 0;

        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[current][i] && !used[i])
            {
                options[count++] = i;
            }
        }

        if(count == 0)
        {
            printf("Racunar nema potez. TI POBEDUJES!\n");
            break;
        }

        int ai = options[rand() % count];

        used[ai] = 1;
        current = ai;

        printf("RACUNAR -> %s\n", g->words[current]);

        hasMove = 0;
        for(int i = 0; i < g->n; i++)
        {
            if(g->mat[current][i] && !used[i])
            {
                hasMove = 1;
                break;
            }
        }

        if(!hasMove)
        {
            printf("Igrac nema potez. RACUNAR POBEDUJE!\n");
            break;
        }
    }

    free(used);
}

int main()
{
    Graph g;

    g.mat = NULL;
    g.words = NULL;
    g.n = 0;

    char filename[100];

    printf("Unesi ime fajla: ");
    scanf("%s", filename);

    read_from_file(filename, &g);

    srand(time(NULL));

    int choice;

    while (1)
    {
        printf("\n========================\n");
        printf("      KALADONT MENU     \n");
        printf("========================\n");
        printf("1. DFS prikaz\n");
        printf("2. Korisnost reci\n");
        printf("3. Efikasnost reci\n");
        printf("4. Opasnost reci\n");
        printf("5. Ispisi graf (matrica)\n");
        printf("6. Igraj igru\n");
        printf("0. Izlaz\n");
        printf("========================\n");

        printf("Izaberi opciju: ");
        scanf("%d", &choice);

        if (choice == 0)
            break;

        int idx;

        if (choice >= 1 && choice <= 4)
        {
            printf("Unesi indeks reci (0 - %d): ", g.n - 1);
            scanf("%d", &idx);

            if (idx < 0 || idx >= g.n)
            {
                printf("Nevalidan indeks!\n");
                continue;
            }
        }

        switch (choice)
        {
            case 1:
                DFS(&g, idx);
                break;

            case 2:
                printf("Korisnost: %d\n", korisnost(&g, idx));
                break;

            case 3:
                printf("Efikasnost: %d\n", efikasnost(&g, idx));
                break;

            case 4:
                printf("Opasnost: %d\n", opasnost(&g, idx));
                break;

            case 5:
                print_graph(&g);
                break;

            case 6:
                play_game(&g);
                break;

            default:
                printf("Nepoznata opcija!\n");
        }
    }

    free_graph(&g);

    printf("Kraj programa.\n");

    return 0;
}
